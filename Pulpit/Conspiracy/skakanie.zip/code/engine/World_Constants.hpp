class World_Constants{

public:

int floor_height;
sf::Vector2f player_size;
int gravitational_force;
int jmp_velocity;

World_Constants();



};

World_Constants::World_Constants(){
	
floor_height = 0.25*SCRHEIGHT;
player_size = sf::Vector2f(50,50);
jmp_velocity = 30;
gravitational_force = 2;

};
